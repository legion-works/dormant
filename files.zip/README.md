# softkvm

Soft KVM over DDC/CI. One monitor, two inputs, two machines (CachyOS/KDE +
macOS), each running the same ~330-line Go binary. A "switch" is a DDC/CI
command telling the monitor which input to show. Triggers: HTTP hotkey
(`/toggle`) or activity-follow (idle-edge detection). No auth — trusted LAN
only (v1).

## How it works

Both peers can command the monitor to either input, so switching never
depends on the other machine being awake. The HTTP peer link only syncs the
`owner` flag. Activity-follow claims the monitor on an **activity edge**:
input arriving after ≥ `arm_after_s` (7 s) of local idle. That one rule is the
anti-flap logic — after you hotkey away, continuous typing on the other box
never yanks the monitor back; you have to leave the keyboard and return.

## Install

### Linux (CachyOS)
```fish
sudo pacman -S ddcutil
sudo usermod -aG i2c $USER   # then re-login; ddcutil needs /dev/i2c-*
ddcutil detect               # confirm the monitor answers
ddcutil capabilities | grep -A9 'Feature: 60'   # lists your input codes
go build -ldflags="-s -w" -o ~/.local/bin/softkvm .
cp config.linux.json ~/.config/softkvm.json     # edit peer IP + inputs
cp ops/softkvm.service ~/.config/systemd/user/
systemctl --user enable --now softkvm
```

### macOS (Apple Silicon)
```sh
brew install m1ddc           # Intel Macs: use ddcctl and override ddc_set/ddc_get
GOOS=darwin GOARCH=arm64 go build -ldflags="-s -w" -o softkvm .
sudo cp softkvm /usr/local/bin/
cp config.mac.json ~/.config/softkvm.json       # edit peer IP + inputs
cp ops/xyz.tehan.softkvm.plist ~/Library/LaunchAgents/   # fix paths if needed
launchctl load ~/Library/LaunchAgents/xyz.tehan.softkvm.plist
```

Common VCP 0x60 input values: DP1=15, DP2=16, HDMI1=17, HDMI2=18, USB-C
often 27 — but check `ddcutil capabilities`, vendors vary.

## First run

```sh
softkvm -config softkvm.json -probe     # shows current DDC input + live idle readings
softkvm -config softkvm.json -dry-run   # runs the service but only prints DDC commands
```

If `-probe` idle numbers look like milliseconds instead of seconds (i.e. jump
by ~1000 per second), set `"idle_divisor": 1000` in the config.

## Hotkeys

The binary deliberately has no hotkey code (Wayland/macOS global-hotkey
capture is where these tools go to bloat). Bind at the OS level:

- **KDE**: System Settings → Shortcuts → Add Command:
  `curl -s -X POST http://127.0.0.1:8377/toggle`
- **macOS**: skhd (`brew install skhd`), in `~/.config/skhd/skhdrc`:
  `f18 : curl -s -X POST http://127.0.0.1:8377/toggle`
  (or a Shortcuts/Karabiner binding running the same curl)

Since it's plain HTTP, anything can drive it — Home Assistant, a Stream Deck,
`curl` from either box targeting the other's IP.


## Hooks (automations)

Ownership transitions run commands from config. `before_*` hooks **block the
switch** (10 s cap) — pause media, sync clipboard, then the monitor moves.
`after_*` hooks run async. Env vars: `SOFTKVM_EVENT`, `SOFTKVM_REASON`
(toggle / api / activity / peer-claimed / peer-released), `SOFTKVM_OWNER`.

```json
"hooks": {
  "before_move_away": ["playerctl", "pause"],
  "after_move_away":  ["curl", "-s", "-X", "POST", "http://ha.local:8123/api/webhook/desk-left"],
  "after_acquire":    ["curl", "-s", "-X", "POST", "http://ha.local:8123/api/webhook/desk-back"]
}
```

Hooks fire on *every* ownership change, including ones the peer initiated —
that's the other job of the peer sync. One caveat: when the peer initiates,
the monitor has physically already switched, so `before_*` there guarantees
ordering (before `after_*`), not timing.

## API

| Endpoint                | Effect                              |
|-------------------------|-------------------------------------|
| `POST /claim`           | monitor → this machine              |
| `POST /release`         | monitor → peer                      |
| `POST /toggle`          | flip                                |
| `GET /status`           | JSON state                          |
| `POST /notify/claimed`  | (peer-to-peer) peer took monitor    |
| `POST /notify/released` | (peer-to-peer) peer handed it to me |

## Config reference

| Key               | Default (linux / mac)                                  | Notes                          |
|-------------------|--------------------------------------------------------|--------------------------------|
| `listen`          | `0.0.0.0:8377`                                         |                                |
| `peer`            | —                                                      | `http://<other-box>:8377`      |
| `my_input`        | required                                               | `"15"` or `"0x0f"` both work   |
| `peer_input`      | required                                               |                                |
| `ddc_set`         | `ddcutil setvcp 60` / `m1ddc set input`                | input value appended           |
| `ddc_get`         | `ddcutil getvcp 60 --brief` / `m1ddc get input`        | best-effort startup seed       |
| `idle_source`     | `kde-dbus` / `mac-ioreg`                               | `none` disables polling        |
| `idle_divisor`    | `1`                                                    | `1000` if D-Bus returns ms     |
| `activity_follow` | `false`                                                | set `true` to enable           |
| `poll_ms`         | `1000`                                                 |                                |
| `arm_after_s`     | `7`                                                    | idle needed before an edge     |
| `cooldown_s`      | `3`                                                    | edge suppression after switch  |
| `hooks`           | `{}`                                                   | see Hooks section              |

Second monitor later: override `ddc_set` (e.g. `ddcutil -d 2 setvcp 60` or
`m1ddc display 2 set input`) in a second instance on another port, or chain
two commands in a wrapper script. USB switch later: changes nothing here —
activity naturally follows whichever machine receives input.
