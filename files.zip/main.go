// softkvm — a soft KVM switch over DDC/CI.
//
// Two machines share one monitor on two inputs. Each runs this binary.
// A switch = telling the monitor (via DDC/CI) which input to show.
// Hotkeys are external: bind a key to `curl -X POST localhost:8377/toggle`.
// Activity-follow: idle-time polling; an "activity edge" after >= arm_after_s
// of idle claims the monitor. Continuous typing never steals it back.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/exec"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

// ---------------------------------------------------------------- config

type Config struct {
	Listen         string   `json:"listen"`          // e.g. "0.0.0.0:8377"
	Peer           string   `json:"peer"`            // e.g. "http://192.168.1.20:8377"
	MyInput        string   `json:"my_input"`        // VCP 0x60 value of MY input, e.g. "15" or "0x0f"
	PeerInput      string   `json:"peer_input"`      // VCP 0x60 value of the peer's input
	DDCSet         []string `json:"ddc_set"`         // command prefix; input value is appended
	DDCGet         []string `json:"ddc_get"`         // command printing current input (optional)
	IdleSource     string   `json:"idle_source"`     // auto | kde-dbus | mac-ioreg | none
	IdleDivisor    float64  `json:"idle_divisor"`    // divide raw idle reading to get seconds (default 1)
	ActivityFollow bool     `json:"activity_follow"` // enable idle-edge claiming
	PollMS         int      `json:"poll_ms"`         // idle poll interval (default 1000)
	ArmAfterS      float64  `json:"arm_after_s"`     // idle needed before an edge counts (default 7)
	CooldownS      float64  `json:"cooldown_s"`      // ignore edges this long after any switch (default 3)

	// Hooks: commands run on ownership transitions, for automations.
	// Keys: before_acquire, after_acquire, before_move_away, after_move_away.
	// before_* hooks block the switch (10s timeout); after_* run async.
	// Env: SOFTKVM_EVENT, SOFTKVM_REASON, SOFTKVM_OWNER.
	Hooks map[string][]string `json:"hooks"`
}

func loadConfig(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	c := &Config{}
	if err := json.Unmarshal(raw, c); err != nil {
		return nil, fmt.Errorf("parse %s: %w", path, err)
	}
	// Platform defaults for anything left empty.
	mac := runtime.GOOS == "darwin"
	if len(c.DDCSet) == 0 {
		if mac {
			c.DDCSet = []string{"m1ddc", "set", "input"}
		} else {
			c.DDCSet = []string{"ddcutil", "setvcp", "60"}
		}
	}
	if len(c.DDCGet) == 0 {
		if mac {
			c.DDCGet = []string{"m1ddc", "get", "input"}
		} else {
			c.DDCGet = []string{"ddcutil", "getvcp", "60", "--brief"}
		}
	}
	if c.IdleSource == "" || c.IdleSource == "auto" {
		if mac {
			c.IdleSource = "mac-ioreg"
		} else {
			c.IdleSource = "kde-dbus"
		}
	}
	if c.Listen == "" {
		c.Listen = "0.0.0.0:8377"
	}
	if c.IdleDivisor == 0 {
		c.IdleDivisor = 1
	}
	if c.PollMS == 0 {
		c.PollMS = 1000
	}
	if c.ArmAfterS == 0 {
		c.ArmAfterS = 7
	}
	if c.CooldownS == 0 {
		c.CooldownS = 3
	}
	if c.MyInput == "" || c.PeerInput == "" {
		return nil, fmt.Errorf("my_input and peer_input are required")
	}
	return c, nil
}

// parseNum reads "15", "0x0f" or "x0f" as a number.
func parseNum(s string) (int64, bool) {
	s = strings.TrimSpace(strings.ToLower(s))
	if strings.HasPrefix(s, "x") {
		s = "0" + s
	}
	n, err := strconv.ParseInt(s, 0, 64)
	return n, err == nil
}

// ---------------------------------------------------------------- server

type Server struct {
	cfg    *Config
	dryRun bool

	mu         sync.Mutex
	owner      bool      // do I currently hold the monitor?
	lastSwitch time.Time // for cooldown
}

func (s *Server) runDDC(input string) error {
	args := append(append([]string{}, s.cfg.DDCSet[1:]...), input)
	if s.dryRun {
		log.Printf("[dry-run] %s %s", s.cfg.DDCSet[0], strings.Join(args, " "))
		return nil
	}
	run := func() error {
		out, err := exec.Command(s.cfg.DDCSet[0], args...).CombinedOutput()
		if err != nil {
			return fmt.Errorf("%w: %s", err, strings.TrimSpace(string(out)))
		}
		return nil
	}
	err := run()
	if err != nil { // DDC is occasionally flaky; one retry
		log.Printf("ddc set failed (%v), retrying", err)
		time.Sleep(300 * time.Millisecond)
		err = run()
	}
	return err
}

// readInput asks the monitor which input is active. Best effort.
func (s *Server) readInput() (int64, error) {
	out, err := exec.Command(s.cfg.DDCGet[0], s.cfg.DDCGet[1:]...).Output()
	if err != nil {
		return 0, err
	}
	// Last parseable token wins: handles "15" (m1ddc) and "VCP 60 SNC x0f" (ddcutil).
	fields := strings.Fields(string(out))
	for i := len(fields) - 1; i >= 0; i-- {
		if n, ok := parseNum(fields[i]); ok {
			return n, nil
		}
	}
	return 0, fmt.Errorf("no numeric input value in %q", strings.TrimSpace(string(out)))
}

// runHook executes the configured command for an event, if any.
// block=true waits (10s cap) so before_* hooks can finish (pause media,
// sync clipboard, ...) before the monitor actually switches.
func (s *Server) runHook(event, reason string, willOwn, block bool) {
	cmd, ok := s.cfg.Hooks[event]
	if !ok || len(cmd) == 0 {
		return
	}
	if s.dryRun {
		log.Printf("[dry-run] hook %s: %s", event, strings.Join(cmd, " "))
		return
	}
	run := func() {
		c := exec.Command(cmd[0], cmd[1:]...)
		c.Env = append(os.Environ(),
			"SOFTKVM_EVENT="+event, "SOFTKVM_REASON="+reason,
			"SOFTKVM_OWNER="+strconv.FormatBool(willOwn))
		done := make(chan error, 1)
		if err := c.Start(); err != nil {
			log.Printf("hook %s: %v", event, err)
			return
		}
		go func() { done <- c.Wait() }()
		select {
		case err := <-done:
			if err != nil {
				log.Printf("hook %s exited: %v", event, err)
			}
		case <-time.After(10 * time.Second):
			c.Process.Kill()
			log.Printf("hook %s timed out, killed", event)
		}
	}
	if block {
		run()
	} else {
		go run()
	}
}

// claim switches the monitor to me; release hands it to the peer.
func (s *Server) claim(reason string)   { s.transition(true, reason, true) }
func (s *Server) release(reason string) { s.transition(false, reason, true) }

// transition is the single place ownership changes. doDDC=false is used when
// the peer already moved the monitor and we only mirror state + fire hooks.
func (s *Server) transition(toMe bool, reason string, doDDC bool) {
	s.mu.Lock()
	if s.owner == toMe {
		s.mu.Unlock()
		return
	}
	s.mu.Unlock()

	kind := "move_away"
	if toMe {
		kind = "acquire"
	}
	s.runHook("before_"+kind, reason, toMe, true)

	if doDDC {
		input := s.cfg.PeerInput
		if toMe {
			input = s.cfg.MyInput
		}
		if err := s.runDDC(input); err != nil {
			log.Printf("switch (%s) failed: %v", reason, err)
			return
		}
		log.Printf("switched monitor -> input %s (%s)", input, reason)
	} else {
		log.Printf("ownership -> %v (%s)", toMe, reason)
	}

	s.mu.Lock()
	s.owner = toMe
	s.lastSwitch = time.Now()
	s.mu.Unlock()

	s.runHook("after_"+kind, reason, toMe, false)
	if doDDC {
		notify := "/notify/released"
		if toMe {
			notify = "/notify/claimed"
		}
		go s.notifyPeer(notify)
	}
}

// notifyPeer is fire-and-forget state sync; a dead peer is fine.
func (s *Server) notifyPeer(path string) {
	if s.cfg.Peer == "" {
		return
	}
	client := &http.Client{Timeout: time.Second}
	if _, err := client.Post(s.cfg.Peer+path, "text/plain", nil); err != nil {
		log.Printf("peer notify %s: %v (ignored)", path, err)
	}
}

// ---------------------------------------------------------------- idle

func (s *Server) readIdleSeconds() (float64, error) {
	switch s.cfg.IdleSource {
	case "kde-dbus":
		out, err := exec.Command("dbus-send", "--session", "--print-reply=literal",
			"--dest=org.freedesktop.ScreenSaver", "/org/freedesktop/ScreenSaver",
			"org.freedesktop.ScreenSaver.GetSessionIdleTime").Output()
		if err != nil {
			return 0, err
		}
		fields := strings.Fields(string(out)) // "uint32 5"
		v, err := strconv.ParseFloat(fields[len(fields)-1], 64)
		if err != nil {
			return 0, err
		}
		return v / s.cfg.IdleDivisor, nil
	case "mac-ioreg":
		out, err := exec.Command("ioreg", "-c", "IOHIDSystem", "-d", "4", "-k", "HIDIdleTime").Output()
		if err != nil {
			return 0, err
		}
		m := regexp.MustCompile(`"HIDIdleTime"\s*=\s*(\d+)`).FindSubmatch(out)
		if m == nil {
			return 0, fmt.Errorf("HIDIdleTime not found")
		}
		ns, _ := strconv.ParseFloat(string(m[1]), 64)
		return ns / 1e9 / s.cfg.IdleDivisor, nil
	}
	return 0, fmt.Errorf("idle source %q disabled", s.cfg.IdleSource)
}

// activityLoop claims the monitor on an activity edge:
// idle resets after having been >= arm_after_s. That single rule is the
// anti-flap logic — continuous typing produces no edges.
func (s *Server) activityLoop() {
	tick := time.NewTicker(time.Duration(s.cfg.PollMS) * time.Millisecond)
	lastIdle, failures := -1.0, 0
	for range tick.C {
		idle, err := s.readIdleSeconds()
		if err != nil {
			if failures++; failures == 3 {
				log.Printf("idle polling failing (%v); will keep retrying quietly", err)
			}
			continue
		}
		failures = 0
		edge := lastIdle >= s.cfg.ArmAfterS && idle < lastIdle
		lastIdle = idle
		if !edge {
			continue
		}
		s.mu.Lock()
		cooling := time.Since(s.lastSwitch) < time.Duration(s.cfg.CooldownS*float64(time.Second))
		needClaim := !s.owner && !cooling
		s.mu.Unlock()
		if needClaim {
			s.claim("activity")
		}
	}
}

// ---------------------------------------------------------------- http

func (s *Server) routes() *http.ServeMux {
	mux := http.NewServeMux()
	post := func(path string, fn func()) {
		mux.HandleFunc("POST "+path, func(w http.ResponseWriter, _ *http.Request) {
			fn()
			w.WriteHeader(http.StatusNoContent)
		})
	}
	post("/claim", func() { s.claim("api") })
	post("/release", func() { s.release("api") })
	post("/toggle", func() {
		s.mu.Lock()
		owner := s.owner
		s.mu.Unlock()
		if owner {
			s.release("toggle")
		} else {
			s.claim("toggle")
		}
	})
	// Peer already moved the monitor: mirror state + fire hooks, never touch DDC.
	// Note: "before_*" hooks here run after the physical switch (it already
	// happened on the peer) — they're kept for ordering, not timing.
	post("/notify/claimed", func() { s.transition(false, "peer-claimed", false) })
	post("/notify/released", func() { s.transition(true, "peer-released", false) })
	mux.HandleFunc("GET /status", func(w http.ResponseWriter, _ *http.Request) {
		s.mu.Lock()
		defer s.mu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{
			"owner": s.owner, "my_input": s.cfg.MyInput, "peer_input": s.cfg.PeerInput,
			"activity_follow": s.cfg.ActivityFollow, "last_switch": s.lastSwitch,
		})
	})
	return mux
}

// ---------------------------------------------------------------- main

func main() {
	cfgPath := flag.String("config", "softkvm.json", "path to config file")
	dryRun := flag.Bool("dry-run", false, "print DDC commands instead of running them")
	probe := flag.Bool("probe", false, "print idle readings + current DDC input, then exit (setup aid)")
	flag.Parse()
	log.SetFlags(log.Ltime)

	cfg, err := loadConfig(*cfgPath)
	if err != nil {
		log.Fatal(err)
	}
	s := &Server{cfg: cfg, dryRun: *dryRun}

	if *probe {
		if v, err := s.readInput(); err == nil {
			log.Printf("monitor reports active input: %d (my_input=%s peer_input=%s)", v, cfg.MyInput, cfg.PeerInput)
		} else {
			log.Printf("ddc read failed: %v", err)
		}
		log.Printf("polling idle via %s for 15s — move the mouse, then leave it:", cfg.IdleSource)
		for i := 0; i < 15; i++ {
			if v, err := s.readIdleSeconds(); err == nil {
				log.Printf("  idle = %.1fs", v)
			} else {
				log.Printf("  idle read failed: %v", err)
			}
			time.Sleep(time.Second)
		}
		return
	}

	// Seed ownership from one best-effort DDC read; assume not-owner on failure.
	if cur, err := s.readInput(); err == nil {
		if want, ok := parseNum(cfg.MyInput); ok {
			s.owner = cur == want
		}
		log.Printf("startup: monitor on input %d, owner=%v", cur, s.owner)
	} else {
		log.Printf("startup: ddc read failed (%v), assuming owner=false", err)
	}

	if cfg.ActivityFollow {
		go s.activityLoop()
	}
	log.Printf("softkvm listening on %s (peer %s, activity_follow=%v)", cfg.Listen, cfg.Peer, cfg.ActivityFollow)
	log.Fatal(http.ListenAndServe(cfg.Listen, s.routes()))
}
